﻿using LDWordProcessor.form;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LDWordProcessor
{
    public partial class UserMenuForm : Form
    {

        public UserMenuForm()
        {
            InitializeComponent();
        }
        private void UserMenuForm_Load(object sender, EventArgs e)
        {
            lbName.Text = Program.AuthUser.Firstname + " " + Program.AuthUser.Surname;
        }

        private void btnPreNewDoc_Click(object sender, EventArgs e)
        {
            Program.isPractice = true;
            DialogResult = DialogResult.OK;
        }

        private void btnNewDoc_Click(object sender, EventArgs e)
        {
            Program.isPractice = false;
            DialogResult = DialogResult.OK;
        }

        private void btnWorkList_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Yes;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
