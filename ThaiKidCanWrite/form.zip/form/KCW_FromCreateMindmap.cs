﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using System.Net;
using LDWordProcessor.db;

namespace LDWordProcessor.form
{
    public partial class KCW_FromCreateMindmap : Form
    {
        private JArray masters;
        private JArray maps;

        public KCW_FromCreateMindmap()
        {
            InitializeComponent();
        }

        private void KCW_PreNewDoc_Load(object sender, EventArgs e)
        {
            btnBack.Hide();
            btnCreateMindmap.Hide();
            btnNext.Hide();

            if (Program.isPractice)
            {
                BasicReq.BReq xx = new BasicReq.BReq();
                int uid = Program.AuthUser.UserID;
                string obj = xx.HttpGet(Program.host_api + "masters?uid=" + uid);
                JObject data = JObject.Parse(obj);
                string status = data.SelectToken("status").ToString();
                if (status.Equals("ok"))
                {
                    masters = (JArray)data.SelectToken("masters");
                    AddPictureToTabPanel();
                }
            }
            else
            {
                temp_picture.BackgroundImage = null;
                AddMindMapToTabPanel();
            }
        }

        private void AddPictureToTabPanel()
        {
            lbTitle.Text = "เลือกโจทย์รูปภาพ";
            list_picture.Controls.Clear();

            FlowLayoutPanel flp = new FlowLayoutPanel();
            flp.AutoScroll = true;
            flp.Dock = System.Windows.Forms.DockStyle.None;
            flp.AutoSize = true;
            flp.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            flp.Location = new System.Drawing.Point(0, 10);
            flp.Name = "fLayoutPnl";
            flp.Dock = DockStyle.Fill;
            var wc = new WebClient();
            foreach (JObject item in masters)
            {
                string id = item.GetValue("id").ToString();
                string photo = item.GetValue("photo_thumbnail").ToString();
                Button b = new Button();
               // b.Size = new Size(230, 160);
                b.Size = new Size(245, 180);

                string image_url = String.Concat(Program.host, photo);
                Image myimage = Image.FromStream(wc.OpenRead(image_url));
                b.BackgroundImage = myimage;
                b.BackgroundImageLayout = ImageLayout.Stretch;
                b.Tag = item;
                b.Click += new EventHandler(SelectPicture);
                flp.Controls.Add(b);
            }
            list_picture.Controls.Add(flp);
        }
        private void AddMindMapToTabPanel()
        {
            lbTitle.Text = "เลือกรูปแบบ Mind Map";
            list_picture.Controls.Clear();

            FlowLayoutPanel flp = new FlowLayoutPanel();
            flp.AutoScroll = true;
            flp.Dock = System.Windows.Forms.DockStyle.None;
            flp.AutoSize = true;
            flp.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            flp.Location = new System.Drawing.Point(0, 10);
            flp.Name = "fLayoutPnl";
            flp.Dock = DockStyle.Fill;
            var wc = new WebClient();
            BasicReq.BReq http = new BasicReq.BReq();

            int uid = Program.AuthUser.UserID;
            string result = http.HttpGet(Program.host_api + "mindmap?uid=" + uid);
            JObject data = JObject.Parse(result);
            string status = data.SelectToken("status").ToString();
            if (status.Equals("ok"))
            {
                maps = (JArray)data.SelectToken("maps");
                foreach (JObject item in maps)
                {
                    string id = item.GetValue("id").ToString();
                    string photo = item.GetValue("image_preview").ToString();
                    Button b = new Button();
                   // b.Size = new Size(225, 160);
                    b.Size = new Size(245, 180);

                    string image_url = String.Concat(Program.host, photo);
                    Image myimage = Image.FromStream(wc.OpenRead(image_url));
                    b.BackgroundImage = myimage;
                    b.BackgroundImageLayout = ImageLayout.Stretch;
                    b.Tag = item;
                    b.Click += new EventHandler(SelectMindMap);
                    flp.Controls.Add(b);
                }
                list_picture.Controls.Add(flp);
            }
        }
        private void SelectPicture(object sender, EventArgs e)
        {
            btnNext.Show();
            Button b = (Button)sender;
            JObject master = (JObject)b.Tag;
            var wc = new WebClient();
            string photo = master.SelectToken("photo_thumbnail").ToString();
            string image_url = String.Concat(Program.host, photo);
            Image myimage = Image.FromStream(wc.OpenRead(image_url));
            temp_picture.BackgroundImage = myimage;
            temp_picture.BackgroundImageLayout = ImageLayout.Stretch;
            Program.SelectPicture = master;
        }
        private void SelectMindMap(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            JObject map = (JObject)b.Tag;
            Program.SelectMap = map;
            temp_map.BackgroundImageLayout = ImageLayout.Stretch;
            btnCreateMindmap.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            btnNext.Show();
            btnBack.Hide();
            btnCreateMindmap.Hide();
            AddPictureToTabPanel();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            lbTitle.Text = "เลือกรูปแบบ Mind Map";
            btnNext.Hide();
            btnBack.Show();
            AddMindMapToTabPanel();
        }

        private void btnCreateMindmap_Click(object sender, EventArgs e)
        {
            if (!Program.isPractice)
            {
                Program.SelectPicture = null;
            }
            DialogResult = DialogResult.Yes;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
