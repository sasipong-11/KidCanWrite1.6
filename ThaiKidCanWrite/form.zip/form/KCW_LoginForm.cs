﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NLog;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace LDWordProcessor
{
    public partial class LoginForm : Form
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        HttpsService http = new HttpsService();
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string idno = "";
            if (txt_username.Text.Trim().Length != 13)
            {
                MessageBox.Show("กรุณากรอกข้อมูลเลขประจำตัวประชาชนให้ครบถ้วน ก่อนเข้าสู่ระบบ", "แจ้งเตือน", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                idno = txt_username.Text.Trim();
            }
            
            try
            {
                // login
                logger.Debug("WebService Auth");
                string result = http.HttpGet("auth?idno=" + idno);
                JObject data = JObject.Parse(result);
                string status = data.SelectToken("status").ToString();
                logger.Debug("Status : " + status);
                if (status.Equals("ok"))
                {
                    JObject user_data = JObject.Parse(data.SelectToken("data").ToString());
                    LDUserBinding user = new LDUserBinding();
                    user.UserID = (int)user_data.SelectToken("uid");
                    user.Firstname = user_data.SelectToken("first_name").ToString();
                    user.Surname = user_data.SelectToken("last_name").ToString();
                    user.Username = user_data.SelectToken("username").ToString();
                    user.Password = "password";
                    user.LastAccess = DateTime.Now.ToString("yyyy'-'MM'-'dd' 'HH':'mm':'ss");
                    bool s_user = LDUserManager.AddUser(user);
                    if (s_user == true)
                    {
                        LDUserManager.SaveUser(user);
                        Program.AuthUser = user;
                        DialogResult = DialogResult.OK;
                    }
                    else
                    {
                        MessageBox.Show("ลองอีกครั้ง", "แจ้งเตือน", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง", "แจ้งเตือน", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }catch (Exception er)
            {
                MessageBox.Show("กรุณาต่ออินเทอร์เน็ต", "แจ้งเตือน", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }
    }

}
